// import { legacy_createStore as createStore } from "redux"
// // import {myReducer} from "./Counter/Reducer"
// import { RootReducer } from "./RootReducer"

// export const myStore = createStore(RootReducer) 

// import { legacy_createStore as createStore } from 'redux';
// import { RootReducer } from './RootReducer';

// export const myStore = createStore(RootReducer);

import { legacy_createStore as createStore,applyMiddleware } from 'redux';
import { RootReducer } from './RootReducer';
import { thunk } from 'redux-thunk';

export const myStore = createStore(RootReducer,applyMiddleware(thunk));