// export const myAction = (payload) => ({
//     type: 'ELEC',
//     payload,
// });

// export const fetchElectronicProducts = () => {
//     return async (dispatch) => {
//         try {
//             const response = await fetch('https://fakestoreapi.com/products/category/electronics')
//             const data = await response.json()
//             dispatch({
//                 type: 'ELEC',
//                 payload: data, 
//             })
//         }
//         catch (error) {
//             console.log(error)
//         }
//     }
// }

import { FETCH_ELECTRONICS, FETCH_PRODUCT_DETAIL } from './productReducer';

export const fetchElectronics = () => async (dispatch) => {
    const response = await fetch('https://fakestoreapi.com/products/category/electronics');
    const data = await response.json();
    console.log('Fetched Electronics:', data); 
    dispatch({
        type: FETCH_ELECTRONICS,
        payload: data,
    });
};

export const fetchProductDetail = (id) => async (dispatch) => {
    const response = await fetch(`https://fakestoreapi.com/products/${id}`);
    const data = await response.json();
    dispatch({
        type: FETCH_PRODUCT_DETAIL,
        payload: data,
    });
};
