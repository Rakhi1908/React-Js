import React from 'react';
import { Link, Outlet } from 'react-router-dom';

export default function Product() {
  return (
    <div>
      <h1>Product Page</h1>
      <Link to="electronic">Go to Electronics</Link>
      <div>
        <Outlet /> {/* This will render nested routes */}
      </div>
    </div>
  );
}
