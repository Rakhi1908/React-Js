import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchProductDetail } from "../Redux/ElecAction";

export default function ProductDetail() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const productDetail = useSelector((state) => state.product.productDetail);

  useEffect(() => {
    dispatch(fetchProductDetail(id));
  }, [dispatch, id]);

  if (!productDetail) {
    return <p>Loading product details...</p>;
  }

  return (
    <div>
      <h1>{productDetail.title}</h1>
      <img src={productDetail.image} alt={productDetail.title} />
      <p>{productDetail.description}</p>
      <p>Price: ${productDetail.price}</p>
    </div>
  );
}
