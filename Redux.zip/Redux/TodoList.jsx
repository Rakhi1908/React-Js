import React, { useState } from "react";

export default function TodoList() {
    const [task, setTask] = useState(""); // To hold the input value
    const [todos, setTodos] = useState([]); // To hold the list of tasks
    const [editingId, setEditingId] = useState(null); // To hold the ID of the task being edited
    const [editingText, setEditingText] = useState(""); // To hold the new task text during edit

    const handleAddTask = () => {
        if (task) {
            setTodos([...todos, { id: Date.now(), text: task, completed: false }]);
            setTask(""); // Clear input field after adding
        }
    };

    const handleToggleTask = (id) => {
        setTodos(todos.map((todo) => 
            todo.id === id ? { ...todo, completed: !todo.completed } : todo
        ));
    };

    const handleDeleteTask = (id) => {
        setTodos(todos.filter((todo) => todo.id !== id));
    };

    const handleEditTask = (id) => {
        const taskToEdit = todos.find((todo) => todo.id === id);
        setEditingId(id);
        setEditingText(taskToEdit.text); // Set the task text to be edited
    };

    const handleSaveEdit = () => {
        if (editingText) {
            setTodos(
                todos.map((todo) =>
                    todo.id === editingId ? { ...todo, text: editingText } : todo
                )
            );
            setEditingId(null); // Clear the editing state
            setEditingText(""); // Clear the editing text
        }
    };

    return (
        <div>
            <h1>Todo List</h1>
            <input
                type="text"
                value={task}
                onChange={(e) => setTask(e.target.value)}
                placeholder="Add a new task"
            />
            <button onClick={handleAddTask}>Add Task</button>

            {editingId && (
                <div>
                    <input
                        type="text"
                        value={editingText}
                        onChange={(e) => setEditingText(e.target.value)}
                        placeholder="Edit task"
                    />
                    <button onClick={handleSaveEdit}>Save Edit</button>
                </div>
            )}

            <ul>
                {todos.map((todo) => (
                    <li key={todo.id} style={{ textDecoration: todo.completed ? "line-through" : "none" }}>
                        <span onClick={() => handleToggleTask(todo.id)}>
                            {todo.text}
                        </span>
                        <button onClick={() => handleEditTask(todo.id)}>Edit</button>
                        <button onClick={() => handleDeleteTask(todo.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}
