export const myAction=(payload)=>{
    return {
        type:"ADD",
        payload
    }
}  