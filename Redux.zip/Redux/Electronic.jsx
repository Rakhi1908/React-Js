import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchElectronics } from './ElecAction';
import { Link } from 'react-router-dom';

export default function Electronic() {
  const dispatch = useDispatch();
  const products = useSelector((state) => state.product.electronicProducts);

  useEffect(() => {
    dispatch(fetchElectronics());
  }, [dispatch]);

  return (
    <div>
      <h1>Electronic Products</h1>
      {products.map((product) => (
        <div key={product.id}>
          <Link to={`/productDetail/${product.id}`}>{product.title}</Link>
        </div>
      ))}
    </div>
  );
}
