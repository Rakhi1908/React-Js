import { combineReducers } from 'redux';
import { ElecReducer } from './ElecReducer';
import { myReducer } from './Counter/Reducer';
import { productReducer } from './productReducer';

export const RootReducer = combineReducers({
  product: ElecReducer,
  counter:myReducer,
  product:productReducer,

});
