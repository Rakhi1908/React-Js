import React from 'react'
import { useSelector } from 'react-redux'

export default function Disply() {
    const data=useSelector((store=>{return store}))
    
    console.log(data)
  return (
    <div>
        {
            data.map((el,i)=>{
                return <li>{el}</li>
            })
        }
    </div>
  )
}
