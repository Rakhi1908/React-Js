// const Elec=[]

// export const ElecReducer=(state=Elec,action)=>{
//     switch(action.type){
//         case 'ELEC':{
//             return {
//                 ...state,
//                 state:action.payload
//             }
//             // return [...state,action.payload]
//         }
//     }
//     return state
// }

const Elec = [];

export const ElecReducer = (state = Elec, action) => {
    switch(action.type) {
        case 'ELEC':
            return action.payload; 
        default:
            return state;
    }
};