// const arr=[]

// export const myReducer=(state=arr,action)=>{
//     if(action.type=="ADD"){
//         state=[
//             ...state,
//             action.payload
//         ]
//     }
//     return state
// } 

// src/component/Redux/Counter/Reducer.js

import { FETCH_DATA_REQUEST, FETCH_DATA_SUCCESS, FETCH_DATA_FAILURE } from './Action';

const initialState = {
  loading: false,
  data: [],
  error: null
};

const counterReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_DATA_REQUEST:
      return { ...state, loading: true };
    case FETCH_DATA_SUCCESS:
      return { ...state, loading: false, data: action.payload };
    case FETCH_DATA_FAILURE:
      return { ...state, loading: false, error: action.error };
    default:
      return state;
  }
};

export default counterReducer; 
