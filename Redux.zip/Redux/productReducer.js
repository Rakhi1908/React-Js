export const FETCH_ELECTRONICS = 'FETCH_ELECTRONICS';
export const FETCH_PRODUCT_DETAIL = 'FETCH_PRODUCT_DETAIL';

const initialState = {
    electronicProducts: [],
    productDetail: null,
};

export const productReducer = (state = initialState, action) => {
    switch (action.type) {
        case FETCH_ELECTRONICS:
            return {
                ...state,
                electronicProducts: action.payload,
            };
        case FETCH_PRODUCT_DETAIL:
            return {
                ...state,
                productDetail: action.payload,
            };
        default:
            return state;
    }
};
