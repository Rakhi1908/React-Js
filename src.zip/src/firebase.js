// Import the functions you need from the SDKs you need
import { getApp, initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAK0TN_GqwHevTecrjK_O_mw1XS7e28J3k",
  authDomain: "final-exam-410be.firebaseapp.com",
  projectId: "final-exam-410be",
  storageBucket: "final-exam-410be.firebasestorage.app",
  messagingSenderId: "838357290727",
  appId: "1:838357290727:web:5183b3841dc70901909c42"
};
  
// Initialize Firebase
export const app = initializeApp(firebaseConfig);