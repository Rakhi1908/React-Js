import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addRecipeThunk } from '../redux/action';
import './RecipeForm.css'; // Import the CSS file

const RecipeForm = () => {
    const [title, setTitle] = useState('');
    const [ingredients, setIngredients] = useState('');
    const dispatch = useDispatch();

    const handleSubmit = (e) => {
        e.preventDefault();
        if (title && ingredients) {
            const newRecipe = {
                title,
                ingredients,
                dateAdded: new Date().toISOString(), // Capture the current date in ISO format
            };
            dispatch(addRecipeThunk(newRecipe)); // Pass the new recipe object
            setTitle('');
            setIngredients('');
        } else {
            alert('Title and ingredients are required');
        }
    };

    return (
        <div className="recipe-form-container">
            <h2>Add a New Recipe</h2>
            <form onSubmit={handleSubmit} className="recipe-form">
                <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Title"
                    className="input-field"
                />
                <input
                    type="text"
                    value={ingredients}
                    onChange={(e) => setIngredients(e.target.value)}
                    placeholder="Ingredients"
                    className="input-field"
                />
                <button type="submit" className="submit-btn">Add Recipe</button>
            </form>
        </div>
    );
};

export default RecipeForm;
