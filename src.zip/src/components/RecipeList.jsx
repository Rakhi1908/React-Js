import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRecipesThunk } from '../redux/action';
import RecipeDetails from './RecipeDetails';
import './RecipeList.css'; // Import the CSS file

const RecipeList = () => {
    const dispatch = useDispatch();
    const recipes = useSelector((state) => state.recipe.recipes);
    const [searchTerm, setSearchTerm] = useState('');
    const [sortOption, setSortOption] = useState('name'); // Default sort by name
    const [filterCategory, setFilterCategory] = useState('');
    const [filterDiet, setFilterDiet] = useState('');

    useEffect(() => {
        dispatch(fetchRecipesThunk());
    }, [dispatch]);

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleSortChange = (e) => {
        setSortOption(e.target.value);
    };

    const handleCategoryFilter = (e) => {
        setFilterCategory(e.target.value);
    };

    const handleDietFilter = (e) => {
        setFilterDiet(e.target.value);
    };

    // Filter recipes based on search term, category, and dietary preference
    const filteredRecipes = recipes
        .filter((recipe) => 
            recipe.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
            (filterCategory ? recipe.category === filterCategory : true) &&
            (filterDiet ? recipe.dietaryPreference === filterDiet : true)
        )
        .sort((a, b) => {
            if (sortOption === 'name') {
                return a.title.localeCompare(b.title); // Sort by name
            } else if (sortOption === 'date') {
                return new Date(b.dateAdded) - new Date(a.dateAdded); // Sort by date added
            }
            return 0;
        });

    return (
        <div className="recipe-list-container">
            <h2>Recipe List</h2>
            <div className="filters">
                <input
                    type="text"
                    placeholder="Search by title"
                    value={searchTerm}
                    onChange={handleSearch}
                    className="search-input"
                />
                <select onChange={handleSortChange} value={sortOption}>
                    <option value="name">Sort by Name</option>
                    <option value="date">Sort by Date Added</option>
                </select>
                <select onChange={handleCategoryFilter} value={filterCategory}>
                    <option value="">Filter by Category</option>
                    <option value="vegetarian">Vegetarian</option>
                    <option value="vegan">Vegan</option>
                    <option value="glutenFree">Gluten Free</option>
                    {/* Add more categories as needed */}
                </select>
                <select onChange={handleDietFilter} value={filterDiet}>
                    <option value="">Filter by Dietary Preference</option>
                    <option value="lowCarb">Low Carb</option>
                    <option value="keto">Keto</option>
                    <option value="paleo">Paleo</option>
                    {/* Add more dietary preferences as needed */}
                </select>
            </div>
            <div className="recipe-list">
                {filteredRecipes.length === 0 ? (
                    <p>No recipes available</p>
                ) : (
                    filteredRecipes.map((recipe) => (
                        <RecipeDetails key={recipe.id} recipe={recipe} />
                    ))
                )}
            </div>
        </div>
    );
};

export default RecipeList;
