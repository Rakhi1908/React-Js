import React, { useState } from "react";
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import { app } from "../firebase"; // Ensure you have your Firebase setup

const auth = getAuth(app);

const SignUp = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleSignUp = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    try {
      await createUserWithEmailAndPassword(auth, email, password);
      setSuccessMessage("Account created successfully! Please log in.");
      setError(""); // Clear any previous error messages
      // Redirect user to login page or login after sign up
    } catch (error) {
      setError(error.message); // Display error message if sign-up fails
    }
  };

  const containerStyle = {
    width: "100%",
    maxWidth: "400px",
    margin: "50px auto",
    padding: "30px",
    backgroundColor: "#f9f9f9",
    borderRadius: "8px",
    boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
  };

  const headerStyle = {
    textAlign: "center",
    fontSize: "28px",
    color: "#333",
    marginBottom: "20px",
  };

  const formStyle = {
    display: "flex",
    flexDirection: "column",
  };

  const labelStyle = {
    fontSize: "14px",
    color: "#555",
    marginBottom: "5px",
  };

  const inputStyle = {
    padding: "12px",
    fontSize: "16px",
    border: "1px solid #ddd",
    borderRadius: "5px",
    marginBottom: "15px",
    transition: "all 0.3s ease",
  };

  const inputFocusStyle = {
    borderColor: "#3498db",
    outline: "none",
  };

  const buttonStyle = {
    padding: "12px",
    fontSize: "16px",
    backgroundColor: "#3498db",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    transition: "all 0.3s ease",
  };

  const buttonHoverStyle = {
    backgroundColor: "#2980b9",
  };

  const successMessageStyle = {
    color: "green",
    textAlign: "center",
  };

  const errorMessageStyle = {
    color: "red",
    textAlign: "center",
  };

  return (
    <div style={containerStyle}>
      <h2 style={headerStyle}>Create Account</h2>
      <form onSubmit={handleSignUp} style={formStyle}>
        <div>
          <label style={labelStyle}>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            style={inputStyle}
          />
        </div>
        <div>
          <label style={labelStyle}>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={inputStyle}
          />
        </div>
        <div>
          <label style={labelStyle}>Confirm Password:</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            style={inputStyle}
          />
        </div>
        {error && <p style={errorMessageStyle}>{error}</p>}
        {successMessage && <p style={successMessageStyle}>{successMessage}</p>}
        <button
          type="submit"
          style={{ ...buttonStyle, ":hover": buttonHoverStyle }}
        >
          Sign Up
        </button>
      </form>
    </div>
  );
};

export default SignUp;
