import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { deleteRecipeThunk, updateRecipeThunk } from "../redux/action";

const RecipeDetails = ({ recipe }) => {
    const dispatch = useDispatch();

    // Local state to handle the editing form
    const [isEditing, setIsEditing] = useState(false);
    const [newTitle, setNewTitle] = useState(recipe.title);
    const [newIngredients, setNewIngredients] = useState(recipe.ingredients);

    const handleDelete = () => {
        dispatch(deleteRecipeThunk(recipe.id));
    };

    const handleUpdate = (e) => {
        e.preventDefault();
        const updatedRecipe = { ...recipe, title: newTitle, ingredients: newIngredients };
        dispatch(updateRecipeThunk(recipe.id, updatedRecipe));
        setIsEditing(false); // Close the edit form after saving
    };

    return (
        <div className="recipe-details">
            {isEditing ? (
                <form onSubmit={handleUpdate}>
                    <div>
                        <label>Title:</label>
                        <input
                            type="text"
                            value={newTitle}
                            onChange={(e) => setNewTitle(e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <label>Ingredients:</label>
                        <textarea
                            value={newIngredients}
                            onChange={(e) => setNewIngredients(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit" className="save-btn">Save</button>
                    <button type="button" onClick={() => setIsEditing(false)} className="cancel-btn">
                        Cancel
                    </button>
                </form>
            ) : (
                <>
                    <h3>{recipe.title}</h3>
                    <p>{recipe.ingredients}</p>
                    <button className="edit-btn" onClick={() => setIsEditing(true)}>Edit</button>
                    <button className="delete-btn" onClick={handleDelete}>Delete</button>
                </>
            )}
        </div>
    );
};

export default RecipeDetails;
