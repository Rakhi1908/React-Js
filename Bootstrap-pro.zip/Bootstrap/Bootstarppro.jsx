import React from 'react';
import { Container, Navbar, Nav, Row, Col } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './App.css';

const App = () => {
  return (
    <div className="app">
      {/* Header */}
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand href="#home">RAKHI</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mx-auto">
              <Nav.Link href="#">Home</Nav.Link>
              <Nav.Link href="#">About</Nav.Link>
              <Nav.Link href="#">Contact</Nav.Link>
              <Nav.Link href="#">Blog</Nav.Link>
              <Nav.Link href="#">Project</Nav.Link>
            </Nav>
            <Nav>
              <Nav.Link href="#">
                <div className="icon-container">
                  <i className="bi bi-bag-fill"></i>
                  <i className="bi bi-twitter"></i>
                  <i className="bi bi-facebook"></i>
                </div>
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Img section */}
      <Container fluid className="image-container">
        <Row>
          <Col>
            <h1 className="text-light text-center">Build Your Dream With Passion</h1>
            <p className="text-light text-center">
              Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusm tempor
              <br />incididunt ut labore et dolore.
            </p>
            <a href="#">GET STARTED</a>
          </Col>
        </Row>
      </Container>

      {/* About section */}
      <Container>
        <Row>
          <Col>
            <div className="about-sec">
              <div className="about-text">
                <h5>ABOUT US</h5>
                <h1>We are the Best Construction Company in the World</h1>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  <br />Sed do eiusmod tempor incididunt ut labore et dolore
                  <br />magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                  <br />ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <a href="#" className="contact-link">CONTACT US</a>
              </div>
              <div className="about-img">
                <img
                  src="https://castro.jamstacktemplates.dev/assets/img/backgrounds/video-cta.jpg"
                  alt="Construction site background"
                />
              </div>
            </div>
          </Col>
        </Row>
      </Container>

      {/* Services section */}
      <Container>
        <Row>
          <Col>
            <br /><br />
            <h1>Our Services</h1>
            <div className="services-images">
              <div className="box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/service/service1.jpg" alt="Service 1" />
                <div className="box-text">
                  <h2>Power and Energy</h2>
                  <p>Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                  <a href="#">SEE MORE</a>
                </div>
              </div>
              <div className="box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/service/service2.jpg" alt="Service 2" />
                <div className="box-text">
                  <h2>Work Management</h2>
                  <p>Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                  <a href="#">SEE MORE</a>
                </div>
              </div>
              <div className="box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/service/service3.jpg" alt="Service 3" />
                <div className="box-text">
                  <h2>Material Engineering</h2>
                  <p>Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                  <a href="#">SEE MORE</a>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>

      {/* Counter section */}
      <Container fluid className="count-container">
        <Row>
          <Col>
            <div className="counter">
              <div className="counter-box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/icons/funfact-project.png" alt="Projects Icon" />
                <h1 className="counter-value"><span>598</span></h1>
                <h4>Projects</h4>
              </div>

              <div className="counter-box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/icons/funfact-clients.png" alt="Clients Icon" />
                <h1 className="counter-value"><span>124</span></h1>
                <h4>Clients</h4>
              </div>

              <div className="counter-box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/icons/funfact-success.png" alt="Success Icon" />
                <h1 className="counter-value"><span>350</span></h1>
                <h4>Success</h4>
              </div>

              <div className="counter-box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/icons/funfact-award.png" alt="Award Icon" />
                <h1 className="counter-value"><span>120</span></h1>
                <h4>Awards</h4>
              </div>
            </div>
          </Col>
        </Row>
      </Container>

      {/* Blog section */}
      <Container>
        <Row>
          <Col>
            <div className="blog-sec">
              <h1>New Blog</h1>
              <div className="blog-box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/blog/1.jpg" alt="" />
                <div className="blog-text">
                  <p>AUGUST 4, 2019</p>
                  <h3>Industry Ministry to Hike</h3>
                  <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Saepe minus, illo error ratione eos ex.…</p>
                  <a href="#">SEE MORE</a>
                </div>
              </div>
              <div className="blog-box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/blog/2.jpg" alt="" />
                <div className="blog-text">
                  <p>AUGUST 5, 2019</p>
                  <h3>Worker Safety: India Appeals</h3>
                  <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Saepe minus, illo error ratione eos ex.…</p>
                  <a href="#">SEE MORE</a>
                </div>
              </div>
              <div className="blog-box">
                <img src="https://castro.jamstacktemplates.dev/assets/img/blog/3.jpg" alt="" />
                <div className="blog-text">
                  <p>AUGUST 6, 2019</p>
                  <h3>Industry Ministry to Hike</h3>
                  <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Saepe minus, illo error ratione eos ex.…</p>
                  <a href="#">SEE MORE</a>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>

      {/* Logo section */}
      <div className="logo-sec">
        <img src="https://castro.jamstacktemplates.dev/assets/img/brand-logo/1.png" alt="Logo 1" />
        <img src="https://castro.jamstacktemplates.dev/assets/img/brand-logo/2.png" alt="Logo 2" />
        <img src="https://castro.jamstacktemplates.dev/assets/img/brand-logo/3.png" alt="Logo 3" />
        <img src="https://castro.jamstacktemplates.dev/assets/img/brand-logo/1.png" alt="Logo 1" />
        <img src="https://castro.jamstacktemplates.dev/assets/img/brand-logo/2.png" alt="Logo 2" />
      </div>

      {/* Footer */}
      <footer className="bg-dark text-light py-5">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h5>Contact Us</h5>
              <p>Email: contact@mywebsite.com</p>
              <p>Phone: +1 (123) 456-7890</p>
            </div>
            <div className="col-md-6">
              <h5>Find Us</h5>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434509233!2d144.9556513153172!3d-37.81627997975187!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0d178ff7%3A0x11a7c0a8e44e0db9!2sVictoria%20State%20Library!5e0!3m2!1sen!2sau!4v1623982342151!5m2!1sen!2sau"
                width="100%"
                height="250"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                title="Google Map"
              />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
export default App;