const express = require("express");
const userModel = require("./model/userModel");
const db = require("./config/db");
const app = express();

app.set("view engine", "ejs");
app.use(express.urlencoded());

app.get("/", async (req, res) => {
    // res.send("hello rk!..");
    const books = await userModel.find();
    res.render("index", { books });
});

app.post("/insert", async (req, res) => {
    const { name, author,description,language,price } = req.body;
    await userModel.create({ name, author,description,language,price });
    res.redirect("/");
});

app.get("/delete", (req, res) => {
    const id = req.query.id;
    userModel.findByIdAndDelete(id)
        .then(() => {
            res.redirect("/")
        }).catch((err) => {
            console.log(err)
        })
});

app.get("/edit", async (req, res) => {
    try {
        const id = req.query.id;
        const data = await userModel.findById(id);
        if (data) {
            res.render("edit",{books:data});
        } else {
            res.send("not found!");
        }
    } catch(err){
        console.log(err)
    }
});

app.post("/update", async (req,res)=>{
    try{
        const id = req.body.id;
        const{editname,editauthor,editdescription,editlanguage,editprice} = req.body
        await userModel.findByIdAndUpdate(id,{
            name: editname,
            author: editauthor,
            description:editdescription,
            language:editlanguage,
            price:editprice
        });
        res.redirect("/");
    } catch(err){
        console.log(err)
    }
   
})

app.listen(8080, () => {
    console.log("server listening");
});