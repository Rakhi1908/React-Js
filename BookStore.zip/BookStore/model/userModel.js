const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    name: {
        type: String
    },
    author: {
        type: String
    },
    description:{
        type:String
    },
    language:{
        type:String
    },
    price:{
        type:String
    }
});

const userModel = mongoose.model("book", userSchema);
module.exports = userModel;