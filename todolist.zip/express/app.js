// const express = require("express")
// const app = express();
// app.set("view engine", "ejs")
// app.use(express.urlencoded())
// var studentData = [
//     {
//         "id": 1,
//         "name": "rakhi"
//     },
//     {
//         "id": 2,
//         "name": "mahi"
//     }
// ]

// app.get("/", (req, res) => {
//     //res.send("first route")
//     res.render("home", {
//         studentData
//     })
// })

// app.post("/insert", (req, res) => {
//     const { id, name } = req.body;
//     var obj = {
//         id: id,
//         name: name
//     }
//     studentData.push(obj)
//     res.redirect("back")
// })
// app.get("/delete/:id", (req, res) => { 
//     // console.log(req.query.id)
// var id = req.params.id;
//     const { id } = req.query.id; //query is used for get method and params is used for post method
//     // console.log(id)
//    ans= studentData = studentData.filter((el,i) => { 
//         return el.id != id 
// })
//     studentData=ans; //yaha ans me jo bhe data h vo studentData me aa jayega
//     res.redirect("/") //isme "/" bhe le sakte h or "back" bhe use kar sakte h ki data kaha se delete hua h vo dikhe sake 
// })
// app.listen(7800, () => {  
//     console.log("server listen")   
// })

const express = require("express");
const bodyParser = require("body-parser");

const app = express();

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));

let studentData = [
  { id: 1, name: "rakhi" },
  { id: 2, name: "mahi" },
];

// Render Home Page
app.get("/", (req, res) => {
  res.render("home", { studentData });
});

// Add New Student
app.post("/add", (req, res) => {
  const { id, name } = req.body;
  studentData.push({ id: parseInt(id), name });
  res.redirect("/"); 
});

// Edit Student Data
app.post("/edit/:index", (req, res) => { 
  const index = parseInt(req.params.index);
  const { id, name } = req.body;

  if (index >= 0 && index < studentData.length) {
    studentData[index] = { id: parseInt(id), name }; 
  }

  res.redirect("/"); 
});

// Delete Student
app.get("/delete/:index", (req, res) => {
  const index = parseInt(req.params.index);  

  if (index >= 0 && index < studentData.length) { 
    studentData.splice(index, 1);
  }

  res.redirect("/");
});

// Start Server
app.listen(7800, () => {
  console.log("Server is running on http://localhost:7800");
}); 


//midleware
//astictic middleware