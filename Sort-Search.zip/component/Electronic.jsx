import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function Electronic() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('https://fakestoreapi.com/products/category/electronics')
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  const Searching = (e) => {
    setSearch(e.target.value);
  };

  const Sorting = (e) => {
    const sortedProducts = [...products];
    if (e.target.value === "priceLowHigh") sortedProducts.sort((a, b) => a.price - b.price);
    else if (e.target.value === "priceHighLow") sortedProducts.sort((a, b) => b.price - a.price);
    setProducts(sortedProducts);
  };

  const filtered = products.filter(product =>
    product.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <h2>Electronic</h2>
      <input
        type="text"
        placeholder="Search products"
        value={search}
        onChange={Searching}
      />
      <select id="sort" onChange={Sorting}>
        <option value="">Sort by</option>
        <option value="priceLowHigh">Price: Low to High</option>
        <option value="priceHighLow">Price: High to Low</option>
      </select>
      <div>
        {filtered.map((el, i) => (
          <div key={i}>
            <Link to={`/ProductDetail/${el.id}`}>{el.title}</Link>
            <p>Price: ${el.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
}