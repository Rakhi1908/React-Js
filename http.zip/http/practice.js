const http = require('http')
const fs = require('fs')

const server = http.createServer((req, res) => {
  const path = req.url
  const method = req.method

  console.log(new Date(), path, method)

  if (path.includes('file') && method === 'GET') {
    const filename = path.split('/').pop()
    try {
      const data = fs.readFileSync('./' + filename)
      res.end(data)
    } catch (err) {
      res.statusCode = 404
      res.end('File not found')
    }
  } else if (path === '/about' && method === 'GET') {
    res.end('This is the about page')
  } else {
    res.end('Page not found')
  }
})

server.listen(7500, () => {
  console.log('server running on port 7500')
})
