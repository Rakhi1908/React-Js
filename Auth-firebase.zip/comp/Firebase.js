import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyBlzTiJ-FxwbOLSVN7e3aC2eFEZ_BHQsOU",
  authDomain: "login-3aed3.firebaseapp.com",
  projectId: "login-3aed3",
  storageBucket: "login-3aed3.firebasestorage.app",
  messagingSenderId: "829409941570",
  appId: "1:829409941570:web:b9f806974dfc65aeecb5db",
};

export const app = initializeApp(firebaseConfig);